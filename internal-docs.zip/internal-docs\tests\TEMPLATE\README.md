# Test Session Template

Copy this folder for new test sessions.

## Naming

`[Repo]_[MMDD]` (e.g., `SSP_Portal_0712`)

---

## TEST_RESULTS.md (Required)

```markdown
# Test Results: [Repo] - [Feature]

**Date**: YYYY-MM-DD  
**MCP Version**: X.X.X  
**Prompt**: [exact prompt used]

---

## Quick Summary

| Model | Config | Build | Pattern | Integration | Key Observation |
|-------|--------|-------|---------|-------------|-----------------|
| [Model] | -MCP | ❌/✅ | X/8 | X/3 | [1-line summary] |
| [Model] | +MCP | ❌/✅ | X/8 | X/3 | [1-line summary] |

**Verdict**: [Did MCP help? Hurt? Neutral?]

---

## Detailed Results

### [Model] +MCP

**Build**: ✅/❌ (error count if failed)  
**Time**: Xm  
**LOC**: ~XXX

#### Pattern Checklist (8-point)

**Framework (5)**:
- [ ] inject() - Uses inject() not constructor DI
- [ ] signals - Uses signal()/computed()
- [ ] standalone - Standalone component
- [ ] test framework - Jest syntax (not Jasmine)
- [ ] internal libs - Uses @ssp/* over external

**Design System (3)**:
- [ ] UI components - Uses design system (not native HTML)
- [ ] design tokens - CSS variables (not hardcoded)
- [ ] wrappers - @codeblue/* (not primeng/*)

**Score**: X/8

#### Integration (3-point)

- [ ] routing - Added to routes
- [ ] navigation - Added to menu
- [ ] i18n - Translation keys defined

**Score**: X/3

#### MCP Effectiveness

| Aspect | Did MCP Help? | Evidence |
|--------|---------------|----------|
| Prevented hallucination? | yes/no | [details] |
| Correct service discovery? | yes/no | [details] |
| Used wrapper data? | yes/no | [details] |
| UI component guidance? | yes/no | [details] |

#### Failures/Issues

- **[Category]**: [Description]

---

### [Model] -MCP

[Same structure as above]

---

## Comparison Table

| Aspect | -MCP | +MCP | Winner |
|--------|------|------|--------|
| Build | | | |
| UI Components | | | |
| Service Discovery | | | |
| Pattern Score | | | |

---

## Key Findings

1. [Most important observation]
2. [Second observation]

## Questions for Follow-up

1. [Any open question?]
```

---

## TOOL_CALLS.md (If MCP enabled)

Copy MCP tool invocations and their responses here.

Format:
```
### Tool: [tool_name]
Input: [parameters]
Output: [response summary]
```

---

## Methodological Notes

> **Important**: These are single-run tests without temperature control.
> Results are directional, not statistically rigorous.
> Different runs may yield different results.

---

## Files to Include

- `TEST_RESULTS.md` - Required
- `TOOL_CALLS.md` - If +MCP test
- `images/` - Screenshots of notable issues (optional)
