# Project Rules
- This is an Angular project
- Use TypeScript
